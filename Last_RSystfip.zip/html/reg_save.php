<?php

$payload = json_decode(file_get_contents('php://input'));
if (!$payload) {
  http_response_code(400);
  exit('bad request');
}

$person   = $payload->person;
$name     = ucwords(strtolower($payload->name));
$doctype  = $payload->doctype;
$doc      = $payload->doc;
$facultie = $payload->facultie;
$asunt    = ucfirst(strtolower($payload->asunt));
$color    = $payload->color;
$date     = $payload->date;
$start    = $payload->start;
$end      = $payload->end;
$status   = $payload->status;

if ('unset' === $person) {
  echo json_encode([
    'error' => 'Seleccione el tipo de persona a agendar'
  ]);
  return;
} elseif (empty($name)) {
  echo json_encode([
    'error' => 'Ingrese los nombres'
  ]);
  return;
} elseif ('unset' === $doctype) {
  echo json_encode([
    'error' => 'Debe seleccionar el tipo de documento'
  ]);
  return;
} elseif ('unset' === $facultie) {
  $facultie = 4;
} elseif (empty($doc)) {
  echo json_encode([
    'error' => 'Ingrese el número de documento'
  ]);
  return;
} elseif (empty($asunt)) {
  echo json_encode([
    'error' => 'Ingrese el motivo de la visita a la Rectoría - ITFIP'
  ]);
  return;
} elseif (!ctype_alpha($name) && ctype_space($name)) {
  echo json_encode([
    'error' => 'El nombre sólo puede contener letras'
  ]);
  return;
} elseif (!is_numeric((int) $doc)) {
  echo json_encode([
    'error' => 'El número de documento no puede contener letras'
  ]);
  return;
} elseif (strlen($doc) < 8) {
  echo json_encode([
    'error' => 'El número de documento debe tener al menos 8 caracteres'
  ]);
  return;
}

include_once 'session_check.php';
use RSystfip\PeopleController as pc;
if ($person === '4') {
  pc::saveStaffDeans($doc, $name, $facultie);
}
echo json_encode([
  'ok' => pc::schedule($name, $doctype, $doc, $person, $facultie, $asunt, $color, $date, $start, $end, $status),
  'redirect' => $status === 2 ? '/schedule-people-list' : false
]);