<?php

require_once 'vendor/autoload.php';

$request = Laminas\Diactoros\ServerRequestFactory::fromGlobals(
  $_SERVER,
  $_GET,
  $_POST,
  $_COOKIE,
  $_FILES
);

$router = new Aura\Router\RouterContainer();
$map = $router->getMap();
$map->get('index', '/', 'login.php');
$map->get('sign in', '/signin', 'login.php');
$map->post('logging in', '/logging-in', 'logging_in.php');
$map->get('home', '/home', 'home.php');
$map->get('people', '/schedule-people-list', 'people.php');
$map->get('get people', '/get-people', 'get_people.php');
$map->get('scheduling', '/do-scheduled-scheduling', 'people_scheduling.php');
$map->get('schedule', '/do-fast-scheduling', 'people_add.php');
$map->post('save schedule', '/reg-save', 'reg_save.php');
$map->get('people edit', '/edit-data-person', 'people_edit.php');
$map->get('register', '/view-scheduling-register', 'people_register.php');
$map->get('reports', '/generate-reports-by-date', 'people_reports.php');
$map->get('get reports', '/get-reports-by-date', 'get_reports_by_date.php');
$map->get('statistics', '/generate-statistics-by-date', 'people_statistics.php');
$map->get('people download', '/RSystfip-report-' . RSystfip\TimeController::todayDate(), 'report.php');
$map->get('help', '/fqs', 'faq.php');
$map->get('admin', '/manage-users', 'dashboard_users.php');
$map->get('add user', '/assign-role-new-user', 'add_user.php');
$map->post('save user', '/save-user', 'save_user.php');
$map->get('change password', '/change-password', 'change_password.php');
$map->post('update password', '/update-password', 'update_password.php');
$map->get('delete user', '/delete-user', 'delete_user.php');

$matcher = $router->getMatcher();
$route   = $matcher->match($request);
$url     = $router->getGenerator();
!$route ? $file = '404.php' : $file = $route->handler;
require $_SERVER['DOCUMENT_ROOT'] . "/$file";