</section>
<footer class="px-3 py-2 fixed-bottom bg-dark">
  <span class="text-secondary">Sistema de Agendamiento
    <span class="text-white">RSystfip</span>
    &nbsp;|&nbsp;
    <span class="text-white">
      Técnica Profesional en Programación Web <i class="fa fa-code"></i>
    </span>
  </span>
</footer>
</body>
</html>