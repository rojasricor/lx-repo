<?php

include_once 'vendor/autoload.php';
use RSystfip\SessionController as sc;

sc::logOut();
sc::redirectIfNotLoggedIn();