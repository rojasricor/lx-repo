<?php

include_once 'vendor/autoload.php';
RSystfip\SessionController::redirectIfNotLoggedIn();