<?php

if (!isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['confirm_password'])) {
  http_response_code(400);
  exit('bad request');
}

$cargo    = $_POST['cargo'];
$id       = $cargo-1;
$name     = ucwords(strtolower($_POST['name']));
$lastname = ucwords(strtolower($_POST['lastname']));
$doctype  = $_POST['doctype'];
$document = $_POST['document'];
$phone    = $_POST['tel'];
$email    = strtolower($_POST['email']);
$pass     = $_POST['password'];
$passConf = $_POST['confirm_password'];

if ($cargo !== '2' && $cargo !== '3') {
  header(sprintf('Location: %s?tab=2&cargo_no_seleccionado', $url->generate('add user')));
  exit;
}

if ('unset' === $doctype) {
  header(sprintf('Location: %s?tab=2&tipo_documento_no_seleccionado', $url->generate('add user')));
  exit;
}

if ($pass !== $passConf) {
  header(sprintf('Location: %s?tab=2&nueva_password_no_coincide', $url->generate('add user')));
  exit;
}

include_once 'session_check.php';
use RSystfip\UserController as uc;

$cargoExists = uc::getOneById($id);

if (cargoExists) {
  header(sprintf('Location: %s?tab=2&cargo_existente', $url->generate('add user')));
  exit;
}

$emailExists = uc::getOneByEmail($email);

if ($emailExists) {
  header(sprintf('Location: %s?tab=2&correo_existente', $url->generate('add user')));
  exit;
}

uc::create($id, $cargo, $name, $lastname, $doctype, $document, $phone, $email, $pass);
header(sprintf('Location: %s?tab=2', $url->generate('admin')));