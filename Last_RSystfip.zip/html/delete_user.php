<?php

if (!isset($_GET['role'])) {
  http_response_code(400);
  exit('bad request');
}

include_once 'session_check.php';
RSystfip\UserController::delete(base64_decode($_GET['role']));
header(sprintf('Location: %s?tab=2', $url->generate('delete user')));