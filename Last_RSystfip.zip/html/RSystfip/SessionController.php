<?php

namespace RSystfip;

class SessionController
{
  static function logOut()
  {
    self::sessionStart();
    session_destroy();
  }

  static function propagateUser($id, $role, $name, $email, $permissions)
  {
    self::sessionStart();
    return $_SESSION['sess'] = ['id'=>$id, 'role'=>$role, 'name'=>$name, 'email'=>$email, 'permissions'=>$permissions];
  }

  static function sessionStart()
  {
    if (session_status() !== PHP_SESSION_ACTIVE) {
      session_start();
    }
  }

  static function redirectIfNotLoggedIn()
  {
    self::sessionStart();
    if (!$_SESSION) {
      header('Location: /signin');
    }
  }
}
