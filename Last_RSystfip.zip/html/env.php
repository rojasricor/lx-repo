<?php exit; ?>
MYSQL_DB   = 'rsystfip_db'
MYSQL_USER = 'admin'
MYSQL_PSW  = 'admin'
MYSQL_HOST = 'localhost'