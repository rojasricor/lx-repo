<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RSystfip | Sistema de Agendamiento Rectoría ITFIP</title>
  <meta name="description" content="Sistema de agendamiento Rectoría ITFIP">
  <meta name="author" content="Ricardo Rojas, José Mendoza">
  <link rel="icon" href="/img/favicon.svg">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="/styles/style.min.css" type="text/css">
</head>
<body>
  <section class="container-fluid">