<?php

if (!isset($_POST['id']) || !isset($_POST['current_password']) || !isset($_POST['new_password']) || !isset($_POST['new_password_confirm'])) {
  http_response_code(400);
  exit('bad request');
}

$id_encoded         = $_POST['id'];
$id_decoded         = base64_decode($_POST['id']);
$currentPassword    = $_POST['current_password'];
$newPassword        = $_POST['new_password'];
$confirmNewPassword = $_POST['new_password_confirm'];

if ($newPassword !== $confirmNewPassword) {
  header(sprintf('Location: %s?tab=2&role=%s&nueva_password_no_coincide', $url->generate('change password'), $id_encoded));
  exit;
}

include_once 'session_check.php';
use RSystfip\UserController as uc;

if (!uc::authById($id_decoded, $currentPassword)) {
  header(sprintf('Location: %s?tab=2&role=%s&antigua_password_incorrecta', $url->generate('change password'), $id_encoded));
  exit;
}

uc::updatePassword($id_decoded, $newPassword);

header(sprintf('Location: %s?tab=2&role=%s&password_cambiada', $url->generate('change password'), $id_encoded));