<?php

$payload = json_decode(file_get_contents('php://input'));
if (!$payload) {
  http_response_code(400);
  exit('bad request');
}

$domainOk = 'itfip.edu.co';
$username = filter_var($payload->username, FILTER_VALIDATE_EMAIL);
$password = $payload->password;
$domain   = explode('@', $username)[1] ?? false;

if (empty($username)) {
  echo json_encode([
    'error' => 'Ingrese el correo.'
  ]);
  return;
} elseif ($domain !== $domainOk) {
  echo json_encode([
    'error' => "El dominio del correo no es $domainOk."
  ]);
  return;
} elseif (empty($password)) {
  echo json_encode([
    'error' => 'Ingrese la contraseña.'
  ]);
  return;
} elseif (strlen($password) < 8) {
  echo json_encode([
    'error' => 'La contraseña no tiene más de 8 caracteres.'
  ]);
  return;
}

include_once 'vendor/autoload.php';
$auth = RSystfip\UserController::auth($username, $password);

if ($auth) {
  echo json_encode([
    'auth' => $auth,
    'redirect' => $url->generate('home')
  ]);
} else {
  echo json_encode([
    'error' => 'El usuario o la contraseña son incorrectos.'
  ]);
}