import "./styles.css";

export default function App() {
  return (
    <div className="loader-container">
      <div className="circle1">
        <div className="circle2"></div>
      </div>
    </div>
  );
}
